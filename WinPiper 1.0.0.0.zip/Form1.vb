﻿


Imports System.IO
Imports System.Security.Policy
Imports System.Text
Imports System.Threading






Public Class Form1

    ' UNCESSARY VARIABLES - Only for demos, or part of optional functions 
    Dim randomSentenceIndex As Integer = 0



    ' For Simulating a Text Stream
    Public testLargeSentenceBlock As String = $"
Large Language Models (LLMs) are sophisticated artificial intelligence systems designed to understand, generate, and interact with human language in a highly advanced manner. 
They are based on deep learning architectures, particularly transformer models, which are trained on vast amounts of textual data. 
The scale of these models—often involving billions or even trillions of parameters—enables them to capture a wide range of language patterns, including grammar, syntax, context, and even nuances like tone and emotion. 
LLMs are typically pre-trained on massive datasets drawn from a diverse array of sources, including books, articles, websites, and other publicly available text. 
Once trained, they can perform a wide variety of natural language processing (NLP) tasks, such as text generation, translation, summarization, question answering, and sentiment analysis.
"



    Function GetRandomSentence() As String
        ' Create the list of sentences
        Dim testSentences As New List(Of String) From {
        "The old oak tree stood tall, its branches swaying gently in the breeze.",
        "Beneath it, a group of children played, their laughter filling the air.",
        "As the sun began to set, the sky turned a brilliant orange, casting a warm glow over everything.",
        "The aroma of fresh coffee wafted through the kitchen, enticing everyone to gather around the table.",
        "As they sipped their cups, the conversation shifted to the plans for the weekend getaway.",
        "Excitement filled the room as they mapped out their route, eager for the adventure ahead.",
        "The rain started falling softly, tapping on the windows like a gentle rhythm.",
        "Inside, the fireplace crackled, providing warmth and comfort to everyone gathered near it.",
        "They shared stories, enjoying the quiet moments as the storm raged outside."
    }

        If randomSentenceIndex >= 8 Then
            randomSentenceIndex = 0
        Else
            randomSentenceIndex += 1
        End If

        ' Return the sentence at the randomly generated index
        Return testSentences(randomSentenceIndex)
    End Function










    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        InitializeForm()
    End Sub





    Private Sub InitializeForm()
        FormStreamText.TextBox_TextToStream.Text = testLargeSentenceBlock
        TextBox_PiperONNXPath.Text = Path.Combine(thisAppDir, modelPath)
        TextBox_PiperJSONConfigPath.Text = Path.Combine(thisAppDir, configPath)
        TextBox_WavFileName.Text = Path.Combine(thisAppDir, outputFilePath)
    End Sub





    Private Sub TextBox_TextSendToPiper_TextChanged(sender As Object, e As EventArgs) Handles TextBox_TextSendToPiper.TextChanged

    End Sub

    Private Sub TextBox_SpeechTempo_TextChanged(sender As Object, e As EventArgs) Handles TextBox_SpeechTempo.TextChanged

    End Sub

    Private Sub TextBox_SentenceGapSecs_TextChanged(sender As Object, e As EventArgs) Handles TextBox_SentenceGapSecs.TextChanged

    End Sub

    Private Sub TextBox_NoiseScale_TextChanged(sender As Object, e As EventArgs) Handles TextBox_NoiseScale.TextChanged

    End Sub

    Private Sub TextBox_NoiseW_TextChanged(sender As Object, e As EventArgs) Handles TextBox_NoiseW.TextChanged

    End Sub

    Private Sub TextBox_PiperONNXPath_TextChanged(sender As Object, e As EventArgs) Handles TextBox_PiperONNXPath.TextChanged

    End Sub

    Private Sub Button_BrowseOnnx_Click(sender As Object, e As EventArgs) Handles Button_BrowseOnnx.Click
        Try
            ' Create an OpenFileDialog instance
            Dim openFileDialog As New OpenFileDialog()

            ' If the TextBox_PiperONNXPath.Text is not empty, set the initial directory of the OpenFileDialog
            If Not String.IsNullOrEmpty(TextBox_PiperONNXPath.Text) Then
                If IO.Directory.Exists(Path.GetDirectoryName(TextBox_PiperONNXPath.Text)) Then
                    openFileDialog.InitialDirectory = Path.GetDirectoryName(TextBox_PiperONNXPath.Text)
                End If
            End If

            ' Set filters for the dialog (optional, you can change this based on your need)
            openFileDialog.Filter = "ONNX Files (*.onnx)|*.onnx|All Files (*.*)|*.*"

            ' Show the dialog and check if the user selected a file
            If openFileDialog.ShowDialog() = DialogResult.OK Then
                ' If the user selected a file, set the TextBox with the file path
                TextBox_PiperONNXPath.Text = openFileDialog.FileName
            End If
        Catch ex As Exception
            ' Handle any exceptions (optional)
            MessageBox.Show("An error occurred: " & ex.Message)
        End Try
    End Sub

    Private Sub TextBox_PiperJSONConfigPath_TextChanged(sender As Object, e As EventArgs) Handles TextBox_PiperJSONConfigPath.TextChanged

    End Sub


    Private Sub Button_BrowseJson_Click(sender As Object, e As EventArgs) Handles Button_BrowseJson.Click
        Try
            ' Create an OpenFileDialog instance
            Dim openFileDialog As New OpenFileDialog()

            ' If the TextBox_PiperONNXPath.Text is not empty, set the initial directory of the OpenFileDialog
            If Not String.IsNullOrEmpty(TextBox_PiperJSONConfigPath.Text) Then
                If IO.Directory.Exists(Path.GetDirectoryName(TextBox_PiperJSONConfigPath.Text)) Then
                    openFileDialog.InitialDirectory = Path.GetDirectoryName(TextBox_PiperJSONConfigPath.Text)
                End If
            End If

            ' Set filters for the dialog (optional, you can change this based on your need)
            openFileDialog.Filter = "JSON Files (*.json)|*.json|All Files (*.*)|*.*"

            ' Show the dialog and check if the user selected a file
            If openFileDialog.ShowDialog() = DialogResult.OK Then
                ' If the user selected a file, set the TextBox with the file path
                TextBox_PiperJSONConfigPath.Text = openFileDialog.FileName
            End If
        Catch ex As Exception
            ' Handle any exceptions (optional)
            MessageBox.Show("An error occurred: " & ex.Message)
        End Try
    End Sub



    Private Sub Button_WavFileOutput_OpenFile_Click(sender As Object, e As EventArgs) Handles Button_WavFileOutput_OpenFile.Click
        Try
            OpenFile(TextBox_WavFileName.Text)
        Catch ex As Exception
            MessageBox.Show("Error trying to open file: " & ex.Message)
        End Try
    End Sub


    Private Sub Button_WavFileOutput_OpenFolder_Click(sender As Object, e As EventArgs) Handles Button_WavFileOutput_OpenFolder.Click
        Try
            OpenDirectory(TextBox_WavFileName.Text)
        Catch ex As Exception
            MessageBox.Show("Error trying to open folder: " & ex.Message)
        End Try
    End Sub


    Private Sub Button_WavFileOutput_Browse_Click(sender As Object, e As EventArgs) Handles Button_WavFileOutput_Browse.Click
        Try
            ' Create an OpenFileDialog instance
            Dim openFileDialog As New OpenFileDialog()

            ' If the TextBox_PiperONNXPath.Text is not empty, set the initial directory of the OpenFileDialog
            If Not String.IsNullOrEmpty(TextBox_WavFileName.Text) Then
                If IO.Directory.Exists(Path.GetDirectoryName(TextBox_WavFileName.Text)) Then
                    openFileDialog.InitialDirectory = Path.GetDirectoryName(TextBox_WavFileName.Text)
                End If
            End If

            ' Set filters for the dialog (optional, you can change this based on your need)
            openFileDialog.Filter = "WAVE Files (*.wav)|*.wav|All Files (*.*)|*.*"

            ' Show the dialog and check if the user selected a file
            If openFileDialog.ShowDialog() = DialogResult.OK Then
                ' If the user selected a file, set the TextBox with the file path
                TextBox_WavFileName.Text = openFileDialog.FileName
            End If
        Catch ex As Exception
            ' Handle any exceptions (optional)
            MessageBox.Show("An error occurred: " & ex.Message)
        End Try
    End Sub





    Private Sub CheckBox_OutputToWav_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_OutputToWav.CheckedChanged
        If CheckBox_OutputToWav.Checked = True Then
            TextBox_WavFileName.Enabled = True
            CheckBox_AutoPlayWAV.Enabled = True
            Button_WavFileOutput_OpenFolder.Enabled = True
            Button_WavFileOutput_Browse.Enabled = True
            Button_WavFileOutput_OpenFile.Enabled = True
        Else
            TextBox_WavFileName.Enabled = False
            CheckBox_AutoPlayWAV.Enabled = False
            Button_WavFileOutput_OpenFolder.Enabled = False
            Button_WavFileOutput_Browse.Enabled = False
            Button_WavFileOutput_OpenFile.Enabled = False
        End If
    End Sub


    Private Sub CheckBox_AutoPlayWAV_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox_AutoPlayWAV.CheckedChanged
        If CheckBox_AutoPlayWAV.Checked = True Then
            Button_PiperPause.Enabled = True
            Button_PiperPlay.Enabled = True
        Else
            Button_PiperPause.Enabled = False
            Button_PiperPlay.Enabled = False
        End If
    End Sub



    Private Sub TextBox_WavFileName_TextChanged(sender As Object, e As EventArgs) Handles TextBox_WavFileName.TextChanged

    End Sub



    Private Async Sub Button_Piper_Start_Click(sender As Object, e As EventArgs) Handles Button_Piper_Start.Click
        Try
            Dim inputText As String = TextBox_TextSendToPiper.Text
            Dim speechTempo As Double = CDbl(TextBox_SpeechTempo.Text)
            Dim sentenceSilence As Double = CDbl(TextBox_SentenceGapSecs.Text)
            Dim noiseScale As Double = CDbl(TextBox_NoiseScale.Text)
            Dim noiseW As Double = CDbl(TextBox_NoiseW.Text)
            Dim modelONNXFilePath As String = TextBox_PiperONNXPath.Text
            Dim modelJSONFilePath As String = TextBox_PiperJSONConfigPath.Text
            Dim wavFile As String
            If CheckBox_OutputToWav.Checked = True Then
                wavFile = TextBox_WavFileName.Text
            Else
                wavFile = Nothing
            End If
            Dim autoPlayWavFile As Boolean = CheckBox_AutoPlayWAV.Checked
            Dim forceSpeak As Boolean = True


            'Await Speak(inputText, AddressOf UpdateTextBoxWithQueue, speechTempo, sentenceSilence, noiseScale, noiseW, modelONNXFilePath, modelJSONFilePath, wavFile, autoPlayWavFile)
            Await Speak(inputText, AddressOf UpdateTextBoxWithQueue, speechTempo, sentenceSilence, noiseScale, noiseW, modelONNXFilePath, modelJSONFilePath, wavFile, autoPlayWavFile, forceSpeak)

        Catch ex As Exception
            MessageBox.Show("Error getting values to send to piper" & vbCrLf & vbCrLf & "Error:" & vbCrLf & ex.Message, "Error Getting Values For Piper", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub



    Private Async Sub Button_Piper_Random_Click(sender As Object, e As EventArgs) Handles Button_Piper_Random.Click
        Dim inputText As String = GetRandomSentence()
        Dim speechTempo As Double = CDbl(TextBox_SpeechTempo.Text)
        Dim sentenceSilence As Double = CDbl(TextBox_SentenceGapSecs.Text)
        Dim noiseScale As Double = CDbl(TextBox_NoiseScale.Text)
        Dim noiseW As Double = CDbl(TextBox_NoiseW.Text)
        Dim modelONNXFilePath As String = TextBox_PiperONNXPath.Text
        Dim modelJSONFilePath As String = TextBox_PiperJSONConfigPath.Text
        Dim wavFile As String = ""
        If CheckBox_OutputToWav.Checked = True Then
            wavFile = TextBox_WavFileName.Text
        Else
            wavFile = Nothing
        End If
        Dim autoPlayWavFile As Boolean = CheckBox_AutoPlayWAV.Checked

        UpdateTextBoxWithQueue()
        Await Speak(inputText, AddressOf UpdateTextBoxWithQueue, speechTempo, sentenceSilence, noiseScale, noiseW, modelONNXFilePath, modelJSONFilePath, wavFile, autoPlayWavFile)
        'Await Speak(inputText, AddressOf UpdateTextBoxWithQueue)
    End Sub




    Private Sub Button_Piper_QueueClear_Click(sender As Object, e As EventArgs)
        DequeueAll()
    End Sub



    Private Sub Button_Clear_Queued_Click(sender As Object, e As EventArgs) Handles Button_Clear_Queued.Click
        TextBox_Piper_SentencesQueued.Text = ""
        sentenceQueue.Clear()
        sentencesProcessed.Clear()
        TextBox_Piper_SentencesProcessed.Text = ""
        TextBox_StreamResponse.Clear()
    End Sub



    Private Sub Button_Refresh_Processed_Click(sender As Object, e As EventArgs) Handles Button_Refresh_Processed.Click
        UpdateTextBoxWithQueue()
    End Sub

    Private Sub Button_Clear_Processed_Click(sender As Object, e As EventArgs) Handles Button_Clear_Processed.Click
        TextBox_Piper_SentencesProcessed.Text = ""
    End Sub



    Private Sub MyCallBackFunction()
        'MessageBox.Show("Speech synthesis completed!")
        Console.WriteLine("Speech synthesis completed!")
    End Sub



    Private Sub Button_Piper_Stop_Click(sender As Object, e As EventArgs) Handles Button_Piper_Stop.Click
        CancelPiperOperation()
        Timer_SimulateTextStream.Stop()
    End Sub





    Private Sub Button_PiperPause_Click(sender As Object, e As EventArgs) Handles Button_PiperPause.Click
        PausePlayback()
    End Sub

    Private Async Sub Button_PiperPlay_Click(sender As Object, e As EventArgs) Handles Button_PiperPlay.Click
        Await ResumePlayback()
    End Sub







    Private Sub TextBox_StreamResponse_TextChanged(sender As Object, e As EventArgs) Handles TextBox_StreamResponse.TextChanged

    End Sub


    Private Sub TextBox_StreamInterval_TextChanged(sender As Object, e As EventArgs) Handles TextBox_StreamInterval.TextChanged

    End Sub

    Private Sub Button_TestStream_Click(sender As Object, e As EventArgs) Handles Button_TestStream.Click
        StartStreaming()
    End Sub


    Private Sub Button_StreamCancel_Click(sender As Object, e As EventArgs) Handles Button_StreamCancel.Click
        Timer_SimulateTextStream.Stop()
    End Sub


    Private Sub Button_StreamClear_Click(sender As Object, e As EventArgs) Handles Button_StreamClear.Click
        TextBox_StreamResponse.Clear()
    End Sub








    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs)

    End Sub





    Public Async Sub StartStreaming()
        InitializeTextStream(FormStreamText.TextBox_TextToStream.Text)
        currentWordIndex = 0
        TextBox_StreamResponse.Clear()  ' Clear the TextBox before starting
        currentSentenceBuilder.Clear()  ' clear the Sentence String Builder
        Timer_SimulateTextStream.Interval = CInt(TextBox_StreamInterval.Text)
        Timer_SimulateTextStream.Stop()
        Timer_SimulateTextStream.Start()

        '' silence filler 
        'EnqueueString("great, let me tell you all about it, its a fascinating subject ")
        'UpdateTextBoxWithQueue()

        'While sentenceQueue.Count > 0 And AbortQueueLoop = False
        Await Speak(callback:=AddressOf UpdateTextBoxWithQueue)
        'End While
    End Sub






    ' to populate 'words' variable 
    Public Sub InitializeTextStream(inputString As String)
        Dim pattern As String = "\w+|[.!?;(){}[\]\""-]"
        words = System.Text.RegularExpressions.Regex.Matches(inputString, pattern).
            Cast(Of System.Text.RegularExpressions.Match)().
            Select(Function(m) m.Value).
            ToList()
    End Sub





    ' V1
    Private Async Sub Timer_SimulateTextStream_Tick(sender As Object, e As EventArgs) Handles Timer_SimulateTextStream.Tick
        If currentWordIndex < words.Count Then

            If ConfirmNaturalBreak(words(currentWordIndex).Replace(vbCrLf, " ") & " ") = True Then
                TextBox_StreamResponse.AppendText(words(currentWordIndex))
            Else
                TextBox_StreamResponse.AppendText(" " & words(currentWordIndex))
            End If

            ' DONT await, so it continues running, as it has flags within it to control overlap
            Speak(words(currentWordIndex), callback:=AddressOf UpdateTextBoxWithQueue)

            currentWordIndex += 1
        Else
            ' Stop the timer once all words have been added
            Timer_SimulateTextStream.Stop()
            If currentSentenceBuilder IsNot Nothing Then
                Await Speak(callback:=AddressOf UpdateTextBoxWithQueue)
            End If
        End If
    End Sub





    Public Sub UpdateTextBoxWithQueue()
        Try
            TextBox_Piper_SentencesQueued.Text = String.Join(vbCrLf, sentenceQueue.ToArray())
            TextBox_Piper_SentencesProcessed.Text = String.Join(vbCrLf, sentencesProcessed.ToArray())

            If sentenceQueue.Count = 0 Then
                TextBox_Piper_SentencesQueued.Text = String.Empty
            End If

        Catch ex As Exception
            Console.WriteLine("Error updating textboxes " & ex.Message)
        End Try
    End Sub




    Public Sub OpenDirectory(ByVal directoryPath As String)
        Dim tempDir As String = Path.GetDirectoryName(directoryPath)
        If System.IO.Directory.Exists(tempDir) Then
            Process.Start("explorer.exe", tempDir)
        Else
            MessageBox.Show("Directory does not exist.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub




    Public Sub OpenFile(filePath As String)
        Try
            ' Check if the file exists
            If System.IO.File.Exists(filePath) Then
                ' Open the file using the default application
                Process.Start(filePath)
            Else
                ' File does not exist
                Console.WriteLine("File not found!")
            End If
        Catch ex As Exception
            ' Handle any errors
            Console.WriteLine("Error: " & ex.Message)
        End Try
    End Sub



    Private Sub TestTextStreamMessageToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TestTextStreamMessageToolStripMenuItem.Click
        FormStreamText.ShowDialog()
    End Sub

    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        MsgBox("Simple Module that exposes one primary async function, that uses piper.exe to generate Voice from text." & vbCrLf & vbCrLf & "you can send text in whole blocks, or streamed in chunks - it queues them up automatically and dequeues them until empty in a timley fashion so you cant overlap the audio" & vbCrLf & vbCrLf & "Uses NAudio NuGet Package for audio playback" & vbCrLf & vbCrLf & "Can simultaneously stream from piper into naudio, or output to wavfile, with the option to also auto-playback")
    End Sub

End Class






