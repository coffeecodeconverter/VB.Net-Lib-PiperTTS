﻿Public Class FormStreamText
    Private Sub FormStreamText_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If TextBox_TextToStream.Text = "" Then
            TextBox_TextToStream.Text = Form1.testLargeSentenceBlock
        End If
    End Sub
End Class