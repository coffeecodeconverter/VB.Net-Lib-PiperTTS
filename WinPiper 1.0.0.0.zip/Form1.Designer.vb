﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button_StreamClear = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.TextBox_StreamResponse = New System.Windows.Forms.TextBox()
        Me.Button_StreamCancel = New System.Windows.Forms.Button()
        Me.Button_TestStream = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBox_StreamInterval = New System.Windows.Forms.TextBox()
        Me.Timer_SimulateTextStream = New System.Windows.Forms.Timer(Me.components)
        Me.Button_Piper_Start = New System.Windows.Forms.Button()
        Me.Button_Piper_Stop = New System.Windows.Forms.Button()
        Me.TextBox_TextSendToPiper = New System.Windows.Forms.TextBox()
        Me.GroupBox_Piper = New System.Windows.Forms.GroupBox()
        Me.Button_WavFileOutput_OpenFile = New System.Windows.Forms.Button()
        Me.Button_WavFileOutput_Browse = New System.Windows.Forms.Button()
        Me.Button_WavFileOutput_OpenFolder = New System.Windows.Forms.Button()
        Me.Button_Piper_Random = New System.Windows.Forms.Button()
        Me.Button_BrowseJson = New System.Windows.Forms.Button()
        Me.Button_BrowseOnnx = New System.Windows.Forms.Button()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.CheckBox_OutputToWav = New System.Windows.Forms.CheckBox()
        Me.CheckBox_AutoPlayWAV = New System.Windows.Forms.CheckBox()
        Me.TextBox_WavFileName = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TextBox_PiperJSONConfigPath = New System.Windows.Forms.TextBox()
        Me.TextBox_PiperONNXPath = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TextBox_SentenceGapSecs = New System.Windows.Forms.TextBox()
        Me.TextBox_SpeechTempo = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TextBox_NoiseW = New System.Windows.Forms.TextBox()
        Me.TextBox_NoiseScale = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Button_PiperPlay = New System.Windows.Forms.Button()
        Me.Button_PiperPause = New System.Windows.Forms.Button()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.MenuStrip_Main = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Button_Clear_Queued = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.TextBox_Piper_SentencesQueued = New System.Windows.Forms.TextBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Button_Refresh_Processed = New System.Windows.Forms.Button()
        Me.Button_Clear_Processed = New System.Windows.Forms.Button()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.TextBox_Piper_SentencesProcessed = New System.Windows.Forms.TextBox()
        Me.EditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TestTextStreamMessageToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GroupBox1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.GroupBox_Piper.SuspendLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.MenuStrip_Main.SuspendLayout()
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.Panel2.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox1.Controls.Add(Me.Button_StreamClear)
        Me.GroupBox1.Controls.Add(Me.Panel1)
        Me.GroupBox1.Controls.Add(Me.Button_StreamCancel)
        Me.GroupBox1.Controls.Add(Me.Button_TestStream)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.TextBox_StreamInterval)
        Me.GroupBox1.Location = New System.Drawing.Point(3, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(925, 178)
        Me.GroupBox1.TabIndex = 14
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Test Streaming Text"
        '
        'Button_StreamClear
        '
        Me.Button_StreamClear.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_StreamClear.Location = New System.Drawing.Point(872, 143)
        Me.Button_StreamClear.Name = "Button_StreamClear"
        Me.Button_StreamClear.Size = New System.Drawing.Size(41, 23)
        Me.Button_StreamClear.TabIndex = 9
        Me.Button_StreamClear.Text = "Clear"
        Me.Button_StreamClear.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.TextBox_StreamResponse)
        Me.Panel1.Location = New System.Drawing.Point(16, 24)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(895, 113)
        Me.Panel1.TabIndex = 4
        '
        'TextBox_StreamResponse
        '
        Me.TextBox_StreamResponse.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox_StreamResponse.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TextBox_StreamResponse.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_StreamResponse.Location = New System.Drawing.Point(0, 0)
        Me.TextBox_StreamResponse.Multiline = True
        Me.TextBox_StreamResponse.Name = "TextBox_StreamResponse"
        Me.TextBox_StreamResponse.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox_StreamResponse.Size = New System.Drawing.Size(893, 111)
        Me.TextBox_StreamResponse.TabIndex = 0
        '
        'Button_StreamCancel
        '
        Me.Button_StreamCancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_StreamCancel.Location = New System.Drawing.Point(831, 143)
        Me.Button_StreamCancel.Name = "Button_StreamCancel"
        Me.Button_StreamCancel.Size = New System.Drawing.Size(40, 23)
        Me.Button_StreamCancel.TabIndex = 8
        Me.Button_StreamCancel.Text = "Stop"
        Me.Button_StreamCancel.UseVisualStyleBackColor = True
        '
        'Button_TestStream
        '
        Me.Button_TestStream.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_TestStream.Location = New System.Drawing.Point(790, 143)
        Me.Button_TestStream.Name = "Button_TestStream"
        Me.Button_TestStream.Size = New System.Drawing.Size(40, 23)
        Me.Button_TestStream.TabIndex = 5
        Me.Button_TestStream.Text = "Test Stream"
        Me.Button_TestStream.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(706, 148)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(42, 13)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Interval"
        '
        'TextBox_StreamInterval
        '
        Me.TextBox_StreamInterval.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_StreamInterval.Location = New System.Drawing.Point(751, 145)
        Me.TextBox_StreamInterval.Name = "TextBox_StreamInterval"
        Me.TextBox_StreamInterval.Size = New System.Drawing.Size(35, 20)
        Me.TextBox_StreamInterval.TabIndex = 6
        Me.TextBox_StreamInterval.Text = "100"
        '
        'Timer_SimulateTextStream
        '
        '
        'Button_Piper_Start
        '
        Me.Button_Piper_Start.Location = New System.Drawing.Point(13, 206)
        Me.Button_Piper_Start.Name = "Button_Piper_Start"
        Me.Button_Piper_Start.Size = New System.Drawing.Size(58, 24)
        Me.Button_Piper_Start.TabIndex = 16
        Me.Button_Piper_Start.Text = "Start"
        Me.Button_Piper_Start.UseVisualStyleBackColor = True
        '
        'Button_Piper_Stop
        '
        Me.Button_Piper_Stop.BackColor = System.Drawing.Color.LightCoral
        Me.Button_Piper_Stop.Location = New System.Drawing.Point(72, 206)
        Me.Button_Piper_Stop.Name = "Button_Piper_Stop"
        Me.Button_Piper_Stop.Size = New System.Drawing.Size(45, 24)
        Me.Button_Piper_Stop.TabIndex = 17
        Me.Button_Piper_Stop.Text = "Stop"
        Me.Button_Piper_Stop.UseVisualStyleBackColor = False
        '
        'TextBox_TextSendToPiper
        '
        Me.TextBox_TextSendToPiper.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_TextSendToPiper.Location = New System.Drawing.Point(122, 25)
        Me.TextBox_TextSendToPiper.Name = "TextBox_TextSendToPiper"
        Me.TextBox_TextSendToPiper.Size = New System.Drawing.Size(822, 20)
        Me.TextBox_TextSendToPiper.TabIndex = 20
        '
        'GroupBox_Piper
        '
        Me.GroupBox_Piper.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox_Piper.Controls.Add(Me.Button_WavFileOutput_OpenFile)
        Me.GroupBox_Piper.Controls.Add(Me.Button_WavFileOutput_Browse)
        Me.GroupBox_Piper.Controls.Add(Me.Button_WavFileOutput_OpenFolder)
        Me.GroupBox_Piper.Controls.Add(Me.Button_Piper_Random)
        Me.GroupBox_Piper.Controls.Add(Me.Button_BrowseJson)
        Me.GroupBox_Piper.Controls.Add(Me.Button_BrowseOnnx)
        Me.GroupBox_Piper.Controls.Add(Me.Label10)
        Me.GroupBox_Piper.Controls.Add(Me.CheckBox_OutputToWav)
        Me.GroupBox_Piper.Controls.Add(Me.CheckBox_AutoPlayWAV)
        Me.GroupBox_Piper.Controls.Add(Me.TextBox_WavFileName)
        Me.GroupBox_Piper.Controls.Add(Me.Label9)
        Me.GroupBox_Piper.Controls.Add(Me.TextBox_PiperJSONConfigPath)
        Me.GroupBox_Piper.Controls.Add(Me.TextBox_PiperONNXPath)
        Me.GroupBox_Piper.Controls.Add(Me.Label6)
        Me.GroupBox_Piper.Controls.Add(Me.Label5)
        Me.GroupBox_Piper.Controls.Add(Me.TextBox_SentenceGapSecs)
        Me.GroupBox_Piper.Controls.Add(Me.TextBox_SpeechTempo)
        Me.GroupBox_Piper.Controls.Add(Me.TextBox_TextSendToPiper)
        Me.GroupBox_Piper.Controls.Add(Me.Label8)
        Me.GroupBox_Piper.Controls.Add(Me.Label7)
        Me.GroupBox_Piper.Controls.Add(Me.TextBox_NoiseW)
        Me.GroupBox_Piper.Controls.Add(Me.TextBox_NoiseScale)
        Me.GroupBox_Piper.Controls.Add(Me.Label4)
        Me.GroupBox_Piper.Controls.Add(Me.Label3)
        Me.GroupBox_Piper.Controls.Add(Me.Label2)
        Me.GroupBox_Piper.Controls.Add(Me.Button_PiperPlay)
        Me.GroupBox_Piper.Controls.Add(Me.Button_PiperPause)
        Me.GroupBox_Piper.Controls.Add(Me.Button_Piper_Start)
        Me.GroupBox_Piper.Controls.Add(Me.Button_Piper_Stop)
        Me.GroupBox_Piper.Location = New System.Drawing.Point(12, 37)
        Me.GroupBox_Piper.Name = "GroupBox_Piper"
        Me.GroupBox_Piper.Size = New System.Drawing.Size(960, 242)
        Me.GroupBox_Piper.TabIndex = 21
        Me.GroupBox_Piper.TabStop = False
        Me.GroupBox_Piper.Text = "Piper Process"
        '
        'Button_WavFileOutput_OpenFile
        '
        Me.Button_WavFileOutput_OpenFile.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_WavFileOutput_OpenFile.Enabled = False
        Me.Button_WavFileOutput_OpenFile.Location = New System.Drawing.Point(737, 159)
        Me.Button_WavFileOutput_OpenFile.Name = "Button_WavFileOutput_OpenFile"
        Me.Button_WavFileOutput_OpenFile.Size = New System.Drawing.Size(68, 23)
        Me.Button_WavFileOutput_OpenFile.TabIndex = 52
        Me.Button_WavFileOutput_OpenFile.Text = "Open File"
        Me.Button_WavFileOutput_OpenFile.UseVisualStyleBackColor = True
        '
        'Button_WavFileOutput_Browse
        '
        Me.Button_WavFileOutput_Browse.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_WavFileOutput_Browse.Enabled = False
        Me.Button_WavFileOutput_Browse.Location = New System.Drawing.Point(887, 159)
        Me.Button_WavFileOutput_Browse.Name = "Button_WavFileOutput_Browse"
        Me.Button_WavFileOutput_Browse.Size = New System.Drawing.Size(57, 23)
        Me.Button_WavFileOutput_Browse.TabIndex = 51
        Me.Button_WavFileOutput_Browse.Text = "Browse"
        Me.Button_WavFileOutput_Browse.UseVisualStyleBackColor = True
        '
        'Button_WavFileOutput_OpenFolder
        '
        Me.Button_WavFileOutput_OpenFolder.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_WavFileOutput_OpenFolder.Enabled = False
        Me.Button_WavFileOutput_OpenFolder.Location = New System.Drawing.Point(807, 159)
        Me.Button_WavFileOutput_OpenFolder.Name = "Button_WavFileOutput_OpenFolder"
        Me.Button_WavFileOutput_OpenFolder.Size = New System.Drawing.Size(79, 23)
        Me.Button_WavFileOutput_OpenFolder.TabIndex = 50
        Me.Button_WavFileOutput_OpenFolder.Text = "Open Folder"
        Me.Button_WavFileOutput_OpenFolder.UseVisualStyleBackColor = True
        '
        'Button_Piper_Random
        '
        Me.Button_Piper_Random.Location = New System.Drawing.Point(13, 181)
        Me.Button_Piper_Random.Name = "Button_Piper_Random"
        Me.Button_Piper_Random.Size = New System.Drawing.Size(58, 24)
        Me.Button_Piper_Random.TabIndex = 49
        Me.Button_Piper_Random.Text = "Random"
        Me.Button_Piper_Random.UseVisualStyleBackColor = True
        '
        'Button_BrowseJson
        '
        Me.Button_BrowseJson.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_BrowseJson.Location = New System.Drawing.Point(887, 112)
        Me.Button_BrowseJson.Name = "Button_BrowseJson"
        Me.Button_BrowseJson.Size = New System.Drawing.Size(57, 23)
        Me.Button_BrowseJson.TabIndex = 48
        Me.Button_BrowseJson.Text = "Browse"
        Me.Button_BrowseJson.UseVisualStyleBackColor = True
        '
        'Button_BrowseOnnx
        '
        Me.Button_BrowseOnnx.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_BrowseOnnx.Location = New System.Drawing.Point(887, 90)
        Me.Button_BrowseOnnx.Name = "Button_BrowseOnnx"
        Me.Button_BrowseOnnx.Size = New System.Drawing.Size(57, 23)
        Me.Button_BrowseOnnx.TabIndex = 47
        Me.Button_BrowseOnnx.Text = "Browse"
        Me.Button_BrowseOnnx.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.SystemColors.ControlDark
        Me.Label10.Location = New System.Drawing.Point(168, 192)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(137, 13)
        Me.Label10.TabIndex = 46
        Me.Label10.Text = "Only with Wav File Playback"
        '
        'CheckBox_OutputToWav
        '
        Me.CheckBox_OutputToWav.AutoSize = True
        Me.CheckBox_OutputToWav.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox_OutputToWav.Location = New System.Drawing.Point(16, 141)
        Me.CheckBox_OutputToWav.Name = "CheckBox_OutputToWav"
        Me.CheckBox_OutputToWav.Size = New System.Drawing.Size(95, 17)
        Me.CheckBox_OutputToWav.TabIndex = 45
        Me.CheckBox_OutputToWav.Text = "Output to WAV"
        Me.CheckBox_OutputToWav.UseVisualStyleBackColor = True
        '
        'CheckBox_AutoPlayWAV
        '
        Me.CheckBox_AutoPlayWAV.AutoSize = True
        Me.CheckBox_AutoPlayWAV.Enabled = False
        Me.CheckBox_AutoPlayWAV.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckBox_AutoPlayWAV.Location = New System.Drawing.Point(122, 141)
        Me.CheckBox_AutoPlayWAV.Name = "CheckBox_AutoPlayWAV"
        Me.CheckBox_AutoPlayWAV.Size = New System.Drawing.Size(92, 17)
        Me.CheckBox_AutoPlayWAV.TabIndex = 44
        Me.CheckBox_AutoPlayWAV.Text = "AutoPlay WAV"
        Me.CheckBox_AutoPlayWAV.UseVisualStyleBackColor = True
        '
        'TextBox_WavFileName
        '
        Me.TextBox_WavFileName.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_WavFileName.Enabled = False
        Me.TextBox_WavFileName.Location = New System.Drawing.Point(122, 160)
        Me.TextBox_WavFileName.Name = "TextBox_WavFileName"
        Me.TextBox_WavFileName.Size = New System.Drawing.Size(613, 20)
        Me.TextBox_WavFileName.TabIndex = 42
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(33, 163)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(78, 13)
        Me.Label9.TabIndex = 43
        Me.Label9.Text = "WAV File Name"
        '
        'TextBox_PiperJSONConfigPath
        '
        Me.TextBox_PiperJSONConfigPath.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_PiperJSONConfigPath.Location = New System.Drawing.Point(122, 114)
        Me.TextBox_PiperJSONConfigPath.Name = "TextBox_PiperJSONConfigPath"
        Me.TextBox_PiperJSONConfigPath.Size = New System.Drawing.Size(763, 20)
        Me.TextBox_PiperJSONConfigPath.TabIndex = 40
        '
        'TextBox_PiperONNXPath
        '
        Me.TextBox_PiperONNXPath.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBox_PiperONNXPath.Location = New System.Drawing.Point(122, 92)
        Me.TextBox_PiperONNXPath.Name = "TextBox_PiperONNXPath"
        Me.TextBox_PiperONNXPath.Size = New System.Drawing.Size(763, 20)
        Me.TextBox_PiperONNXPath.TabIndex = 38
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(169, 73)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(46, 13)
        Me.Label6.TabIndex = 37
        Me.Label6.Text = "Noise W"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(169, 51)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(61, 13)
        Me.Label5.TabIndex = 35
        Me.Label5.Text = "Noise Scale"
        '
        'TextBox_SentenceGapSecs
        '
        Me.TextBox_SentenceGapSecs.Location = New System.Drawing.Point(122, 69)
        Me.TextBox_SentenceGapSecs.Name = "TextBox_SentenceGapSecs"
        Me.TextBox_SentenceGapSecs.Size = New System.Drawing.Size(35, 20)
        Me.TextBox_SentenceGapSecs.TabIndex = 32
        Me.TextBox_SentenceGapSecs.Text = "0.3"
        '
        'TextBox_SpeechTempo
        '
        Me.TextBox_SpeechTempo.Location = New System.Drawing.Point(122, 47)
        Me.TextBox_SpeechTempo.Name = "TextBox_SpeechTempo"
        Me.TextBox_SpeechTempo.Size = New System.Drawing.Size(35, 20)
        Me.TextBox_SpeechTempo.TabIndex = 30
        Me.TextBox_SpeechTempo.Text = "0.8"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(15, 118)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(107, 13)
        Me.Label8.TabIndex = 41
        Me.Label8.Text = "JSON Config File Path:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(15, 96)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(80, 13)
        Me.Label7.TabIndex = 39
        Me.Label7.Text = "ONNX File Path:"
        '
        'TextBox_NoiseW
        '
        Me.TextBox_NoiseW.Location = New System.Drawing.Point(235, 69)
        Me.TextBox_NoiseW.Name = "TextBox_NoiseW"
        Me.TextBox_NoiseW.Size = New System.Drawing.Size(35, 20)
        Me.TextBox_NoiseW.TabIndex = 36
        Me.TextBox_NoiseW.Text = "0.8"
        '
        'TextBox_NoiseScale
        '
        Me.TextBox_NoiseScale.Location = New System.Drawing.Point(235, 47)
        Me.TextBox_NoiseScale.Name = "TextBox_NoiseScale"
        Me.TextBox_NoiseScale.Size = New System.Drawing.Size(35, 20)
        Me.TextBox_NoiseScale.TabIndex = 34
        Me.TextBox_NoiseScale.Text = "0.7"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(15, 73)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(95, 13)
        Me.Label4.TabIndex = 33
        Me.Label4.Text = "Sentence Gap Secs"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(15, 51)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(74, 13)
        Me.Label3.TabIndex = 31
        Me.Label3.Text = "Speech Tempo"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Calibri", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(14, 28)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(71, 13)
        Me.Label2.TabIndex = 29
        Me.Label2.Text = "Text to Speak:"
        '
        'Button_PiperPlay
        '
        Me.Button_PiperPlay.Enabled = False
        Me.Button_PiperPlay.Location = New System.Drawing.Point(225, 206)
        Me.Button_PiperPlay.Name = "Button_PiperPlay"
        Me.Button_PiperPlay.Size = New System.Drawing.Size(56, 24)
        Me.Button_PiperPlay.TabIndex = 28
        Me.Button_PiperPlay.Text = "Play"
        Me.Button_PiperPlay.UseVisualStyleBackColor = True
        '
        'Button_PiperPause
        '
        Me.Button_PiperPause.Enabled = False
        Me.Button_PiperPause.Location = New System.Drawing.Point(168, 206)
        Me.Button_PiperPause.Name = "Button_PiperPause"
        Me.Button_PiperPause.Size = New System.Drawing.Size(56, 24)
        Me.Button_PiperPause.TabIndex = 27
        Me.Button_PiperPause.Text = "Pause"
        Me.Button_PiperPause.UseVisualStyleBackColor = True
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SplitContainer1.Location = New System.Drawing.Point(12, 482)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.GroupBox1)
        Me.SplitContainer1.Size = New System.Drawing.Size(960, 184)
        Me.SplitContainer1.SplitterDistance = 931
        Me.SplitContainer1.TabIndex = 26
        '
        'MenuStrip_Main
        '
        Me.MenuStrip_Main.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.MenuStrip_Main.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.EditToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip_Main.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip_Main.Name = "MenuStrip_Main"
        Me.MenuStrip_Main.Size = New System.Drawing.Size(984, 24)
        Me.MenuStrip_Main.TabIndex = 27
        Me.MenuStrip_Main.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(93, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SplitContainer2.Location = New System.Drawing.Point(12, 286)
        Me.SplitContainer2.Name = "SplitContainer2"
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.Controls.Add(Me.GroupBox4)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.Controls.Add(Me.GroupBox5)
        Me.SplitContainer2.Size = New System.Drawing.Size(960, 194)
        Me.SplitContainer2.SplitterDistance = 480
        Me.SplitContainer2.TabIndex = 28
        '
        'GroupBox4
        '
        Me.GroupBox4.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox4.Controls.Add(Me.Button_Clear_Queued)
        Me.GroupBox4.Controls.Add(Me.Panel3)
        Me.GroupBox4.Location = New System.Drawing.Point(3, 3)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(474, 188)
        Me.GroupBox4.TabIndex = 14
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Queued"
        '
        'Button_Clear_Queued
        '
        Me.Button_Clear_Queued.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Clear_Queued.Location = New System.Drawing.Point(380, 153)
        Me.Button_Clear_Queued.Name = "Button_Clear_Queued"
        Me.Button_Clear_Queued.Size = New System.Drawing.Size(82, 23)
        Me.Button_Clear_Queued.TabIndex = 9
        Me.Button_Clear_Queued.Text = "Clear Queue"
        Me.Button_Clear_Queued.UseVisualStyleBackColor = True
        '
        'Panel3
        '
        Me.Panel3.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.TextBox_Piper_SentencesQueued)
        Me.Panel3.Location = New System.Drawing.Point(16, 24)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(444, 123)
        Me.Panel3.TabIndex = 4
        '
        'TextBox_Piper_SentencesQueued
        '
        Me.TextBox_Piper_SentencesQueued.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox_Piper_SentencesQueued.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TextBox_Piper_SentencesQueued.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_Piper_SentencesQueued.Location = New System.Drawing.Point(0, 0)
        Me.TextBox_Piper_SentencesQueued.Multiline = True
        Me.TextBox_Piper_SentencesQueued.Name = "TextBox_Piper_SentencesQueued"
        Me.TextBox_Piper_SentencesQueued.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox_Piper_SentencesQueued.Size = New System.Drawing.Size(442, 121)
        Me.TextBox_Piper_SentencesQueued.TabIndex = 0
        '
        'GroupBox5
        '
        Me.GroupBox5.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox5.Controls.Add(Me.Button_Refresh_Processed)
        Me.GroupBox5.Controls.Add(Me.Button_Clear_Processed)
        Me.GroupBox5.Controls.Add(Me.Panel4)
        Me.GroupBox5.Location = New System.Drawing.Point(3, 3)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(470, 188)
        Me.GroupBox5.TabIndex = 15
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Processed"
        '
        'Button_Refresh_Processed
        '
        Me.Button_Refresh_Processed.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Refresh_Processed.Location = New System.Drawing.Point(303, 153)
        Me.Button_Refresh_Processed.Name = "Button_Refresh_Processed"
        Me.Button_Refresh_Processed.Size = New System.Drawing.Size(54, 23)
        Me.Button_Refresh_Processed.TabIndex = 10
        Me.Button_Refresh_Processed.Text = "Refresh"
        Me.Button_Refresh_Processed.UseVisualStyleBackColor = True
        '
        'Button_Clear_Processed
        '
        Me.Button_Clear_Processed.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Clear_Processed.Location = New System.Drawing.Point(363, 153)
        Me.Button_Clear_Processed.Name = "Button_Clear_Processed"
        Me.Button_Clear_Processed.Size = New System.Drawing.Size(95, 23)
        Me.Button_Clear_Processed.TabIndex = 9
        Me.Button_Clear_Processed.Text = "Clear Processed"
        Me.Button_Clear_Processed.UseVisualStyleBackColor = True
        '
        'Panel4
        '
        Me.Panel4.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel4.Controls.Add(Me.TextBox_Piper_SentencesProcessed)
        Me.Panel4.Location = New System.Drawing.Point(16, 24)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(440, 123)
        Me.Panel4.TabIndex = 4
        '
        'TextBox_Piper_SentencesProcessed
        '
        Me.TextBox_Piper_SentencesProcessed.BackColor = System.Drawing.Color.White
        Me.TextBox_Piper_SentencesProcessed.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox_Piper_SentencesProcessed.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TextBox_Piper_SentencesProcessed.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox_Piper_SentencesProcessed.Location = New System.Drawing.Point(0, 0)
        Me.TextBox_Piper_SentencesProcessed.Multiline = True
        Me.TextBox_Piper_SentencesProcessed.Name = "TextBox_Piper_SentencesProcessed"
        Me.TextBox_Piper_SentencesProcessed.ReadOnly = True
        Me.TextBox_Piper_SentencesProcessed.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox_Piper_SentencesProcessed.Size = New System.Drawing.Size(438, 121)
        Me.TextBox_Piper_SentencesProcessed.TabIndex = 0
        '
        'EditToolStripMenuItem
        '
        Me.EditToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TestTextStreamMessageToolStripMenuItem})
        Me.EditToolStripMenuItem.Name = "EditToolStripMenuItem"
        Me.EditToolStripMenuItem.Size = New System.Drawing.Size(39, 20)
        Me.EditToolStripMenuItem.Text = "Edit"
        '
        'TestTextStreamMessageToolStripMenuItem
        '
        Me.TestTextStreamMessageToolStripMenuItem.Name = "TestTextStreamMessageToolStripMenuItem"
        Me.TestTextStreamMessageToolStripMenuItem.Size = New System.Drawing.Size(207, 22)
        Me.TestTextStreamMessageToolStripMenuItem.Text = "Test Text Stream Message"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(984, 678)
        Me.Controls.Add(Me.SplitContainer2)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Controls.Add(Me.GroupBox_Piper)
        Me.Controls.Add(Me.MenuStrip_Main)
        Me.MainMenuStrip = Me.MenuStrip_Main
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.GroupBox_Piper.ResumeLayout(False)
        Me.GroupBox_Piper.PerformLayout()
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.MenuStrip_Main.ResumeLayout(False)
        Me.MenuStrip_Main.PerformLayout()
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        Me.SplitContainer2.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer2.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Button_StreamClear As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents TextBox_StreamResponse As TextBox
    Friend WithEvents Button_StreamCancel As Button
    Friend WithEvents Button_TestStream As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents TextBox_StreamInterval As TextBox
    Friend WithEvents Timer_SimulateTextStream As Timer
    Friend WithEvents Button_Piper_Start As Button
    Friend WithEvents Button_Piper_Stop As Button
    Friend WithEvents TextBox_TextSendToPiper As TextBox
    Friend WithEvents GroupBox_Piper As GroupBox
    Friend WithEvents Button_PiperPause As Button
    Friend WithEvents Button_PiperPlay As Button
    Friend WithEvents Label2 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents TextBox_SentenceGapSecs As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents TextBox_SpeechTempo As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents TextBox_NoiseScale As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents TextBox_NoiseW As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents TextBox_PiperJSONConfigPath As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents TextBox_PiperONNXPath As TextBox
    Friend WithEvents TextBox_WavFileName As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents CheckBox_AutoPlayWAV As CheckBox
    Friend WithEvents CheckBox_OutputToWav As CheckBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Button_BrowseJson As Button
    Friend WithEvents Button_BrowseOnnx As Button
    Friend WithEvents SplitContainer1 As SplitContainer
    Friend WithEvents MenuStrip_Main As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SplitContainer2 As SplitContainer
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents Button_Clear_Queued As Button
    Friend WithEvents Panel3 As Panel
    Friend WithEvents TextBox_Piper_SentencesQueued As TextBox
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents Button_Clear_Processed As Button
    Friend WithEvents Panel4 As Panel
    Friend WithEvents TextBox_Piper_SentencesProcessed As TextBox
    Friend WithEvents Button_Piper_Random As Button
    Friend WithEvents Button_Refresh_Processed As Button
    Friend WithEvents Button_WavFileOutput_Browse As Button
    Friend WithEvents Button_WavFileOutput_OpenFolder As Button
    Friend WithEvents Button_WavFileOutput_OpenFile As Button
    Friend WithEvents EditToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TestTextStreamMessageToolStripMenuItem As ToolStripMenuItem
End Class
